import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;	
import javafx.geometry.HPos;
import javafx.scene.paint.Color;

public class SetBoundariesPane extends BorderPane {
	public Button menuButton, setButton;
	public Label text1, text2, errorMessage;
	public Label text3 = new Label("Set a lower boundary:");
	public Label text4 = new Label("Set an upper boundary:");
	public TextField lowerBoundary = new TextField();
	public TextField upperBoundary = new TextField();
	public GridPane mainScreen;
	public HBox error = new HBox();
	
	public SetBoundariesPane(float lowerBound, float upperBound) {
		menuButton = new Button("Return to Main Menu");
		setButton = new Button("Set Boundaries");
		error.setPadding(new Insets(10, 0, 10, 0));
		errorMessage = new Label();
		errorMessage.setTextFill(Color.RED);
		
		text1 = new Label("Current lower boundary: " + lowerBound);
		text2 = new Label("Current upper boundary: " + upperBound);
		
		mainScreen = new GridPane();
		mainScreen.setHgap(5.5);
		mainScreen.setVgap(5.5);
		mainScreen.setPadding(new Insets(50, 10, 10, 30));
		mainScreen.setPrefSize(300,  550);
		mainScreen.setStyle("-fx-background-color: beige;");
		
		mainScreen.add(text1, 0, 0);
		mainScreen.add(text2, 1, 0);
		mainScreen.add(text3, 0, 1);
		mainScreen.add(lowerBoundary, 1, 1);
		mainScreen.add(text4, 0, 2);
		mainScreen.add(upperBoundary, 1, 2);
		
		HBox bottom = new HBox();
		bottom.setPrefSize(400, 50);
		bottom.setPadding(new Insets(10, 12, 10, 12));
		bottom.setAlignment(Pos.BOTTOM_CENTER);
		bottom.setStyle("-fx-border-color: black");
		bottom.getChildren().addAll(setButton);
		
		this.setCenter(mainScreen);
		this.setBottom(bottom);
		this.setTop(menuButton);
	}
			
}

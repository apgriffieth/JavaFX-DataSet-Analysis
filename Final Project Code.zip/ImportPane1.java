import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;	
import javafx.geometry.HPos;
import javafx.scene.paint.Color;

public class ImportPane1 extends BorderPane {
	public Button menuButton, csvButton, txtButton;
	private Label text = new Label("Would you like to import a .csv or "
			+ ".txt file?");
	private Pane mainScreen;
	
	public ImportPane1() {
		menuButton = new Button("Return to Main Menu");
		csvButton = new Button("Import a .csv File");
		txtButton = new Button("Import a .txt File");
		
		mainScreen = new Pane();
		mainScreen.setPrefSize(300, 550);
		mainScreen.setStyle("-fx-background-color: beige;");
		
		HBox textPrompt = new HBox();
		textPrompt.setPrefSize(400, 50);
		textPrompt.setAlignment(Pos.BOTTOM_CENTER);
		textPrompt.getChildren().add(text);
		
		HBox bottom = new HBox();
		bottom.setPrefSize(400, 50);
		bottom.setPadding(new Insets(10, 12, 10, 12));
		bottom.setSpacing(40);
		bottom.setAlignment(Pos.BOTTOM_CENTER);
		bottom.setStyle("-fx-border-color: black");
		bottom.getChildren().addAll(csvButton, txtButton);
		
		menuButton.setAlignment(Pos.TOP_LEFT);
		mainScreen.getChildren().add(menuButton);
		
		this.setCenter(mainScreen);
		this.setBottom(bottom);
		
	}
}

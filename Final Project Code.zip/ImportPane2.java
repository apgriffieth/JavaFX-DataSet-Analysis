import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;	
import javafx.geometry.HPos;
import javafx.scene.paint.Color;

public class ImportPane2 extends BorderPane {
	public Button backButton, newButton, appendButton;
	private Label text = new Label("Would you like to create a new dataset or append to "
			+ "the current dataset?");
	private Pane mainScreen;
	
	public ImportPane2() {
		backButton = new Button("Back");
		newButton = new Button("Create a New Dataset");
		appendButton = new Button("Append to the Current Dataset");
		
		mainScreen = new Pane();
		mainScreen.setPrefSize(300, 550);
		mainScreen.setStyle("-fx-background-color: beige;");
		
		HBox textPrompt = new HBox();
		textPrompt.setPrefSize(400, 50);
		textPrompt.setAlignment(Pos.BOTTOM_CENTER);
		textPrompt.getChildren().add(text);
		
		HBox bottom = new HBox();
		bottom.setPrefSize(400, 50);
		bottom.setPadding(new Insets(10, 12, 10, 12));
		bottom.setSpacing(40);
		bottom.setAlignment(Pos.BOTTOM_CENTER);
		bottom.setStyle("-fx-border-color: black");
		bottom.getChildren().addAll(newButton, appendButton);
		
		backButton.setAlignment(Pos.TOP_LEFT);
		mainScreen.getChildren().add(backButton);
		
		this.setCenter(mainScreen);
		this.setBottom(bottom);
	}
}

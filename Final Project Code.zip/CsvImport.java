import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;	
import javafx.geometry.HPos;
import javafx.scene.paint.Color;

public class CsvImport extends BorderPane{
	
	public Button backButton, importButton, menuButton;
	public TextField fileName = new TextField();
	private Label text = new Label("Enter the .csv filename: ");
	public Label errorMessage;
	public HBox error = new HBox();
	public HBox bottom;

	public CsvImport() {
		menuButton = new Button("Return to Main Menu");
		
		error.setPadding(new Insets(10, 0, 10, 0));
		errorMessage = new Label();
		errorMessage.setTextFill(Color.RED);
		
		GridPane mainScreen = new GridPane();
		mainScreen.setHgap(5.5);
		mainScreen.setVgap(5.5);
		mainScreen.setPadding(new Insets(50, 10, 10, 30));
		mainScreen.setPrefSize(300,  550);
		mainScreen.setStyle("-fx-background-color: beige;");
		
		mainScreen.add(text, 0, 0);
		mainScreen.add(fileName, 1, 0);
		
		backButton = new Button("Back");
		importButton = new Button("Import");
		
		bottom = new HBox();
		bottom.setPrefSize(400, 50);
		bottom.setPadding(new Insets(10, 12, 10, 12));
		bottom.setSpacing(40);
		bottom.setAlignment(Pos.BOTTOM_CENTER);
		bottom.setStyle("-fx-border-color: black");
		bottom.getChildren().addAll(backButton, importButton);
		
		this.setCenter(mainScreen);
		this.setBottom(bottom);
		this.setTop(menuButton);
	}

}

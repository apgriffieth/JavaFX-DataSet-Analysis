import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;	
import javafx.geometry.HPos;
import javafx.scene.paint.Color;
import java.util.*;

public class ErrorPane extends BorderPane {
	public Button menuButton;
	private TextArea textfield = new TextArea();
	
	public ErrorPane(ArrayList<String> errorLog) {
		textfield.setEditable(false);
		menuButton = new Button("Return to Main Menu");
		
		if(!errorLog.isEmpty()) {
			for(int i = 0; i < errorLog.size(); i++) {
				textfield.appendText(errorLog.get(i) + "\n");
			}
		}
		
		this.setCenter(textfield);
		this.setTop(menuButton);
	}

}

import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;	
import javafx.geometry.HPos;
import javafx.scene.paint.Color;
import java.util.*;

public class AnalysisPane extends BorderPane {
	public Button menuButton;
	public Label number, high, low, mean, median, mode;
	private float first, average, middle, value, mostFreq = 0;
	private int maxCount = 0;

	public AnalysisPane(ArrayList<Float> dataSet, float leftBound, float rightBound) {
		menuButton = new Button("Return to Main Menu");
		if(!dataSet.isEmpty()) {
			Collections.sort(dataSet);
			first = dataSet.get(0);
			
			for(int i = 0; i < dataSet.size(); i++) {
				average += dataSet.get(i);
			}		
			average /= dataSet.size();

			if(dataSet.size() % 2 != 0) {
				middle = dataSet.get(dataSet.size() / 2);
			}

			else {
				middle = (dataSet.get(dataSet.size() / 2) + 
						dataSet.get((dataSet.size() / 2) - 1)) / 2;
			}
			
			mostFreq = first;			
			for(int i = 0; i < dataSet.size(); i++) {
				value = dataSet.get(i);
				int count = 0;
				for(int j = 0; j < dataSet.size(); j++) {
					if(value == dataSet.get(j)) {
						count++;
					}
					if(count > maxCount) {
						maxCount = count;
						mostFreq = value;
					}
				}				
			}


			number = new Label("The number of entries is: " + dataSet.size());
			high = new Label("The highest value is: " + Collections.max(dataSet));
			low = new Label("The lowest value is: " + Collections.min(dataSet));
			mean = new Label("The mean of the dataset is: " + average);
			median = new Label("The median of the dataset is: " + middle);
			mode = new Label("The mode of the dataset is: " + mostFreq
					+ " and its frequency is: " + maxCount);
		}
		
		else {
			number = new Label("The number of entries is: 0");
			high = new Label("The highest value is: -");
			low = new Label("The lowest value is: -");
			mean = new Label("The mean of the dataset is: -");
			median = new Label("The median of the dataset is: -");
			mode = new Label("The mode of the dataset is: -");
		}

		GridPane mainScreen = new GridPane();
		mainScreen.setHgap(5.5);
		mainScreen.setVgap(5.5);
		mainScreen.setPadding(new Insets(50, 10, 10, 30));
		mainScreen.setPrefSize(300,  550);
		mainScreen.setStyle("-fx-background-color: beige;");

		mainScreen.add(number, 0, 0);
		mainScreen.add(high, 0, 1);
		mainScreen.add(low, 0, 2);
		mainScreen.add(mean, 0, 3);
		mainScreen.add(median, 0, 4);
		mainScreen.add(mode, 0, 5);

		this.setCenter(mainScreen);
		this.setTop(menuButton);
	}

}

import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;	
import javafx.geometry.HPos;
import javafx.scene.paint.Color;
import java.util.*;

public class DistributionPane extends BorderPane {
	public Button menuButton;
	public Label ninety, eighty, seventy, sixty, fifty, forty, thirty, twenty, ten, zero;
	private int ninetyCount, eightyCount, seventyCount, sixtyCount, fiftyCount, 
	fortyCount, thirtyCount, twentyCount, tenCount, zeroCount = 0;
	private float ninetyTotal, eightyTotal, seventyTotal, sixtyTotal, fiftyTotal, 
	fortyTotal, thirtyTotal, twentyTotal, tenTotal, zeroTotal = 0;
	private float ninetyAvg, eightyAvg, seventyAvg, sixtyAvg, fiftyAvg, fortyAvg,
	thirtyAvg, twentyAvg, tenAvg, zeroAvg = 0;
	public Label ninetyAvgLabel, eightyAvgLabel, seventyAvgLabel, sixtyAvgLabel, 
	fiftyAvgLabel, fortyAvgLabel, thirtyAvgLabel, twentyAvgLabel, tenAvgLabel,
	zeroAvgLabel;

	public DistributionPane(ArrayList<Float> dataSet, float leftBound, float rightBound) {
		menuButton = new Button("Return to Main Menu");

		float distance = (rightBound - leftBound) / 10;

		ninety = new Label("Average within 90 - 100%: ");
		eighty = new Label("Average within 80 - 89%: ");
		seventy = new Label("Average within 70 - 79%: ");
		sixty = new Label("Average within 60 - 69%: ");
		fifty = new Label("Average within 50 - 59%: ");
		forty = new Label("Average within 40 - 49%: ");
		thirty = new Label("Average within 30 - 39%: ");
		twenty = new Label("Average within 20 - 29%: ");
		ten = new Label("Average within 10 - 19%: ");
		zero = new Label("Average within 0 - 9%: ");

		for(int i = 0; i < dataSet.size(); i++) {


			if (dataSet.get(i) / distance < 1) {
				zeroCount++;
				zeroTotal += dataSet.get(i);
			}

			else if (dataSet.get(i) / distance >= 1 && dataSet.get(i) / distance < 2) {
				tenCount++;
				tenTotal += dataSet.get(i);
			}

			else if (dataSet.get(i) / distance >= 2 && dataSet.get(i) / distance < 3) {
				twentyCount++;
				twentyTotal += dataSet.get(i);
			}

			else if (dataSet.get(i) / distance >= 3 && dataSet.get(i) / distance < 4) {
				thirtyCount++;
				thirtyTotal += dataSet.get(i);
			}

			else if (dataSet.get(i) / distance >= 4 && dataSet.get(i) / distance < 5) {
				fortyCount++;	
				fortyTotal += dataSet.get(i);
			}

			else if (dataSet.get(i) / distance >= 5 && dataSet.get(i) / distance < 6) {
				fiftyCount++;
				fiftyTotal += dataSet.get(i);
			}

			else if (dataSet.get(i) / distance >= 6 && dataSet.get(i) / distance < 7) {
				sixtyCount++;
				sixtyTotal += dataSet.get(i);
			}

			else if (dataSet.get(i) / distance >= 7 && dataSet.get(i) / distance < 8) {
				seventyCount++;
				seventyTotal += dataSet.get(i);
			}

			else if (dataSet.get(i) / distance >= 8 && dataSet.get(i) / distance < 9) {
				eightyCount++;
				eightyTotal += dataSet.get(i);
			}

			else {
				ninetyCount++;
				ninetyTotal += dataSet.get(i);
			}
		}

		if(ninetyCount == 0) {
			ninetyAvg = 0;
		}
		else {
			ninetyAvg = ninetyTotal / ninetyCount;
		}
		ninetyAvgLabel = new Label("" + ninetyAvg);

		if(eightyCount == 0) {
			eightyAvg = 0;
		}
		else {
			eightyAvg = eightyTotal / eightyCount;
		}
		eightyAvgLabel = new Label("" + eightyAvg);

		if(seventyCount == 0) {
			seventyAvg = 0;
		}
		else {
			seventyAvg = seventyTotal / seventyCount;
		}
		seventyAvgLabel = new Label("" + seventyAvg);

		if(sixtyCount == 0) {
			sixtyAvg = 0;
		}
		else {
			sixtyAvg = sixtyTotal / sixtyCount;
		}
		sixtyAvgLabel = new Label("" + sixtyAvg);

		if(fiftyCount == 0) {
			fiftyAvg = 0;
		}
		else {
			fiftyAvg = fiftyTotal / fiftyCount;
		}
		fiftyAvgLabel = new Label("" + fiftyAvg);

		if(fortyCount == 0) {
			fortyAvg = 0;
		}
		else {
			fortyAvg = fortyTotal / fortyCount;
		}
		fortyAvgLabel = new Label("" + fortyAvg);

		if(thirtyCount == 0) {
			thirtyAvg = 0;
		}		
		else {
			thirtyAvg = thirtyTotal / thirtyCount;
		}
		thirtyAvgLabel = new Label("" + thirtyAvg);

		if(twentyCount == 0) {
			twentyAvg = 0;
		}
		else {
			twentyAvg = twentyTotal / twentyCount;
		}
		twentyAvgLabel = new Label("" + twentyAvg);

		if(tenCount == 0) {
			tenAvg = 0;
		}
		else {
			tenAvg = tenTotal / tenCount;
		}
		tenAvgLabel = new Label("" + tenAvg);

		if(zeroCount == 0) {
			zeroAvg = 0;
		}
		else {
			zeroAvg = zeroTotal / zeroCount;
		}
		zeroAvgLabel = new Label("" + zeroAvg);

		GridPane mainScreen = new GridPane();
		mainScreen.setHgap(5.5);
		mainScreen.setVgap(5.5);
		mainScreen.setPadding(new Insets(50, 10, 10, 30));
		mainScreen.setPrefSize(300,  550);
		mainScreen.setStyle("-fx-background-color: beige;");

		mainScreen.add(ninety, 0, 0);
		mainScreen.add(ninetyAvgLabel, 1, 0);
		mainScreen.add(eighty, 0, 1);
		mainScreen.add(eightyAvgLabel, 1, 1);
		mainScreen.add(seventy, 0, 2);
		mainScreen.add(seventyAvgLabel, 1, 2);
		mainScreen.add(sixty, 0, 3);
		mainScreen.add(sixtyAvgLabel, 1, 3);
		mainScreen.add(fifty, 0, 4);
		mainScreen.add(fiftyAvgLabel, 1, 4);
		mainScreen.add(forty, 0, 5);
		mainScreen.add(fortyAvgLabel, 1, 5);
		mainScreen.add(thirty, 0, 6);
		mainScreen.add(thirtyAvgLabel, 1, 6);
		mainScreen.add(twenty, 0, 7);
		mainScreen.add(twentyAvgLabel, 1, 7);
		mainScreen.add(ten, 0, 8);
		mainScreen.add(tenAvgLabel, 1, 8);
		mainScreen.add(zero, 0, 9);
		mainScreen.add(zeroAvgLabel, 1, 9);

		this.setCenter(mainScreen);
		this.setTop(menuButton);
	}
}

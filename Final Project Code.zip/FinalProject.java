import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

import java.util.*; // import the ArrayList class and Arrays class
import java.io.*; // import file io streams

public class FinalProject extends Application
{
	Scene MainScreen, ImportScreen1, ImportScreen2, TxtImportScreen, CsvImportScreen, 
	AddDataScreen, DeleteDataScreen, SetBoundariesScreen, AnalysisScreen, 
	DistributionScreen, GraphScreen, ErrorScreen, DisplayScreen;

	public float leftBound;
	public float rightBound;

	public void start(Stage primaryStage)
	{
		//Initialize data containers
		ArrayList<Float> dataset = new ArrayList<Float>(); // the dataset
		ArrayList<String> errorLog = new ArrayList<String>(); // the error log
		leftBound = 0;
		rightBound = 100;


		// Initialize panes
		StartPane startPane = new StartPane();
		ImportPane1 importPane1 = new ImportPane1();
		ImportPane2 importPane2 = new ImportPane2();
		TxtImport txtImportPane = new TxtImport();
		CsvImport csvImportPane = new CsvImport();
		AddDataPane addDataPane = new AddDataPane();
		DeleteDataPane deleteDataPane = new DeleteDataPane();

		// Initialize scenes
		MainScreen = new Scene(startPane, 600, 450);
		ImportScreen1 = new Scene(importPane1, 600, 450);
		ImportScreen2 = new Scene(importPane2, 600, 450);
		TxtImportScreen = new Scene(txtImportPane, 600, 450);
		CsvImportScreen = new Scene(csvImportPane, 600, 450);
		AddDataScreen = new Scene(addDataPane, 600, 450);
		DeleteDataScreen = new Scene(deleteDataPane, 600, 450);

		// Initialize primary stage
		primaryStage.setTitle("Main Menu"); 
		primaryStage.setScene(MainScreen); // Place the scene in the stage
		primaryStage.show(); // Display the stage

		// Handle events
		startPane.importButton.setOnAction(e -> {
			primaryStage.setTitle("Import Menu");
			primaryStage.setScene(ImportScreen1);

			importPane1.menuButton.setOnAction(e1 -> {
				primaryStage.setTitle("Main Menu");
				primaryStage.setScene(MainScreen);
			});

			importPane1.txtButton.setOnAction(e2 -> {
				if(dataset.isEmpty()) {
					primaryStage.setTitle("Import .txt File");
					primaryStage.setScene(TxtImportScreen);
					txtImportPane.setBottom(txtImportPane.bottom);

					txtImportPane.menuButton.setOnAction(a0 -> {
						primaryStage.setTitle("Main Menu");
						primaryStage.setScene(MainScreen);
						txtImportPane.fileName.clear();
					});

					txtImportPane.importButton.setOnAction(a1 -> {
						if(!dataset.isEmpty())
						{
							dataset.clear();
						}
						errorLog.clear();

						try {

							File in = new File(txtImportPane.fileName.getText());
							BufferedReader br = new BufferedReader(new FileReader(in)); 
							String readLine; 

							while ((readLine = br.readLine()) != null) {    			

								try {
									if(Float.parseFloat(readLine) < leftBound) {
										errorLog.add("Error: user file contains the value " + readLine + " below the lower boundary " + leftBound);
										txtImportPane.errorMessage.setText("Error: user file contains the value " + readLine + " below the lower boundary " + leftBound);
										txtImportPane.error.getChildren().clear();
										txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
										txtImportPane.setBottom(txtImportPane.error);
									}
									else if(Float.parseFloat(readLine) > rightBound) {
										errorLog.add("Error: user file contains the value " + readLine + " above the upper boundary " + rightBound);
										txtImportPane.errorMessage.setText("Error: user file contains the value " + readLine + " above the upper boundary " + rightBound);
										txtImportPane.error.getChildren().clear();
										txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
										txtImportPane.setBottom(txtImportPane.error);
									}
									else {
										dataset.add(Float.parseFloat(readLine));
									}

								} catch (NullPointerException nullExc) {
									errorLog.add("Error: NULL POINTER.");
									txtImportPane.errorMessage.setText("Error: NULL POINTER.");
									txtImportPane.error.getChildren().clear();
									txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
									txtImportPane.setBottom(txtImportPane.error);
								} catch (NumberFormatException numExc) {
									errorLog.add("Error: Data being added from file contains an invalid character.");
									txtImportPane.errorMessage.setText("Error: Data being added from file contains an invalid character.");
									txtImportPane.error.getChildren().clear();
									txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
									txtImportPane.setBottom(txtImportPane.error);
								} finally {
								}
							}

							br.close();
						}
						catch (FileNotFoundException FNFExc) {
							errorLog.add("Error: user file " + txtImportPane.fileName.getText() + " not found.");
							//Error: user file not found
							txtImportPane.errorMessage.setText("Error: user file " + txtImportPane.fileName.getText() + " not found.");
							txtImportPane.error.getChildren().clear();
							txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
							txtImportPane.setBottom(txtImportPane.error);

						} 
						catch (IOException IOExc) {
							errorLog.add("Error: IOEXCEPTION.");
							//Error: IOException occurred. 
							txtImportPane.errorMessage.setText("Error: IOEXCEPTION.");
							txtImportPane.error.getChildren().clear();
							txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
							txtImportPane.setBottom(txtImportPane.error);

						}
						finally {
							txtImportPane.fileName.clear();
						}
					});


					txtImportPane.backButton.setOnAction(e3 -> {
						txtImportPane.fileName.clear();
						primaryStage.setTitle("Import Menu");
						primaryStage.setScene(ImportScreen1);
					});
				}

				else {
					primaryStage.setScene(ImportScreen2);

					importPane2.backButton.setOnAction(f1 -> {
						primaryStage.setScene(ImportScreen1);
					});

					importPane2.newButton.setOnAction(f2 -> {
						primaryStage.setTitle("Import .txt File");
						primaryStage.setScene(TxtImportScreen);

						txtImportPane.menuButton.setOnAction(a0 -> {
							primaryStage.setTitle("Main Menu");
							primaryStage.setScene(MainScreen);
							txtImportPane.fileName.clear();
						});

						txtImportPane.importButton.setOnAction(a1 -> {
							if(!dataset.isEmpty())
							{
								dataset.clear();
							}
							errorLog.clear();

							try {

								File in = new File(txtImportPane.fileName.getText());
								BufferedReader br = new BufferedReader(new FileReader(in)); 
								String readLine; 

								while ((readLine = br.readLine()) != null) {    			

									try {
										if(Float.parseFloat(readLine) < leftBound) {
											errorLog.add("Error: user file contains the value " + readLine + " below the lower boundary " + leftBound);
											txtImportPane.errorMessage.setText("Error: user file contains the value " + readLine + " below the lower boundary " + leftBound);
											txtImportPane.error.getChildren().clear();
											txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
											txtImportPane.setBottom(txtImportPane.error);
										}
										else if(Float.parseFloat(readLine) > rightBound) {
											errorLog.add("Error: user file contains the value " + readLine + " above the upper boundary " + rightBound);
											txtImportPane.errorMessage.setText("Error: user file contains the value " + readLine + " above the upper boundary " + rightBound);
											txtImportPane.error.getChildren().clear();
											txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
											txtImportPane.setBottom(txtImportPane.error);
										}
										else {
											dataset.add(Float.parseFloat(readLine));
										}

									} catch (NullPointerException nullExc) {
										errorLog.add("Error: NULL POINTER.");
										txtImportPane.errorMessage.setText("Error: NULL POINTER.");
										txtImportPane.error.getChildren().clear();
										txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
										txtImportPane.setBottom(txtImportPane.error);
									} catch (NumberFormatException numExc) {
										errorLog.add("Error: Data being added from file contains an invalid character.");
										txtImportPane.errorMessage.setText("Error: Data being added from file contains an invalid character.");
										txtImportPane.error.getChildren().clear();
										txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
										txtImportPane.setBottom(txtImportPane.error);
									} finally {
									}
								}

								br.close();
							}
							catch (FileNotFoundException FNFExc) {
								errorLog.add("Error: user file " + txtImportPane.fileName.getText() + " not found.");
								//Error: user file not found
								txtImportPane.errorMessage.setText("Error: user file " + txtImportPane.fileName.getText() + " not found.");
								txtImportPane.error.getChildren().clear();
								txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
								txtImportPane.setBottom(txtImportPane.error);

							} 
							catch (IOException IOExc) {
								errorLog.add("Error: IOEXCEPTION.");
								//Error: IOException occurred. 
								txtImportPane.errorMessage.setText("Error: IOEXCEPTION.");
								txtImportPane.error.getChildren().clear();
								txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
								txtImportPane.setBottom(txtImportPane.error);

							}
							finally {

								for(int i = 0; i < dataset.size(); i++)
								{
									System.out.println(dataset.get(i));
								}

								for(int i = 0; i < errorLog.size(); i++)
								{
									System.out.println(errorLog.get(i));
								}
								txtImportPane.fileName.clear();
							}

							primaryStage.setTitle("Main Menu");
							primaryStage.setScene(MainScreen);
						});


						txtImportPane.backButton.setOnAction(e3 -> {
							txtImportPane.fileName.clear();
							primaryStage.setTitle("Import Menu");
							primaryStage.setScene(ImportScreen2);
						});
					});

					importPane2.appendButton.setOnAction(f3 -> {
						primaryStage.setTitle("Import .txt File");
						primaryStage.setScene(TxtImportScreen);

						txtImportPane.menuButton.setOnAction(a0 -> {
							primaryStage.setTitle("Main Menu");
							primaryStage.setScene(MainScreen);
							txtImportPane.fileName.clear();
						});

						txtImportPane.importButton.setOnAction(a1 -> {
							try {
								File in = new File(txtImportPane.fileName.getText());
								BufferedReader br = new BufferedReader(new FileReader(in)); 
								String readLine; 

								while ((readLine = br.readLine()) != null) {    			

									try {
										if(Float.parseFloat(readLine) < leftBound) {
											errorLog.add("Error: user file contains the value " + readLine + " below the lower boundary " + leftBound);
											txtImportPane.errorMessage.setText("Error: user file contains the value " + readLine + " below the lower boundary " + leftBound);
											txtImportPane.error.getChildren().clear();
											txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
											txtImportPane.setBottom(txtImportPane.error);
										}
										else if(Float.parseFloat(readLine) > rightBound) {
											errorLog.add("Error: user file contains the value " + readLine + " above the upper boundary " + rightBound);
											txtImportPane.errorMessage.setText("Error: user file contains the value " + readLine + " above the upper boundary " + rightBound);
											txtImportPane.error.getChildren().clear();
											txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
											txtImportPane.setBottom(txtImportPane.error);
										}
										else {
											dataset.add(Float.parseFloat(readLine));
										}

									} catch (NullPointerException nullExc) {
										errorLog.add("Error: NULL POINTER.");
										txtImportPane.errorMessage.setText("Error: NULL POINTER.");
										txtImportPane.error.getChildren().clear();
										txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
										txtImportPane.setBottom(txtImportPane.error);
									} catch (NumberFormatException numExc) {
										errorLog.add("Error: Data being added from file contains an invalid character.");
										txtImportPane.errorMessage.setText("Error: Data being added from file contains an invalid character.");
										txtImportPane.error.getChildren().clear();
										txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
										txtImportPane.setBottom(txtImportPane.error);
									} finally {
									}
								}

								br.close();
							}
							catch (FileNotFoundException FNFExc) {
								errorLog.add("Error: user file " + txtImportPane.fileName.getText() + " not found.");
								//Error: user file not found
								txtImportPane.errorMessage.setText("Error: user file " + txtImportPane.fileName.getText() + " not found.");
								txtImportPane.error.getChildren().clear();
								txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
								txtImportPane.setBottom(txtImportPane.error);

							} 
							catch (IOException IOExc) {
								errorLog.add("Error: IOEXCEPTION.");
								//Error: IOException occurred. 
								txtImportPane.errorMessage.setText("Error: IOEXCEPTION.");
								txtImportPane.error.getChildren().clear();
								txtImportPane.error.getChildren().add(txtImportPane.errorMessage);
								txtImportPane.setBottom(txtImportPane.error);

							}
							finally {

								for(int i = 0; i < dataset.size(); i++)
								{
									System.out.println(dataset.get(i));
								}

								for(int i = 0; i < errorLog.size(); i++)
								{
									System.out.println(errorLog.get(i));
								}
								txtImportPane.fileName.clear();
							}

							primaryStage.setTitle("Main Menu");
							primaryStage.setScene(MainScreen);
						});


						txtImportPane.backButton.setOnAction(e3 -> {
							txtImportPane.fileName.clear();
							primaryStage.setTitle("Import Menu");
							primaryStage.setScene(ImportScreen2);
						});
					});
				}
			});

			importPane1.csvButton.setOnAction(e4 -> {
				csvImportPane.setBottom(csvImportPane.bottom);
				if(dataset.isEmpty()) {
					primaryStage.setTitle("Import .csv File");
					primaryStage.setScene(CsvImportScreen);

					csvImportPane.menuButton.setOnAction(a0 -> {
						primaryStage.setTitle("Main Menu");
						primaryStage.setScene(MainScreen);
						csvImportPane.fileName.clear();
					});

					csvImportPane.importButton.setOnAction(a2 -> {
						if(!dataset.isEmpty())
						{
							dataset.clear();
						}
						errorLog.clear();

						try {

							File in = new File(csvImportPane.fileName.getText());
							BufferedReader br = new BufferedReader(new FileReader(in)); 
							String readLine; 

							while ((readLine = br.readLine()) != null) {

								try {
									Float[] floatArr = Arrays.stream(readLine.split(",")).map(Float::valueOf).toArray(Float[]::new);

									for(int i = 0; i < floatArr.length; i++)
									{									
										if(floatArr[i] < leftBound) {
											errorLog.add("Error: user file contains the value " + floatArr[i] + " below the lower boundary " + leftBound);
											csvImportPane.errorMessage.setText("Error: user file contains the value " + floatArr[i] + " below the lower boundary " + leftBound);
											csvImportPane.error.getChildren().clear();
											csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
											csvImportPane.setBottom(csvImportPane.error);
										}
										else if(floatArr[i] > rightBound) {
											errorLog.add("Error: user file contains the value " + floatArr[i] + " above the upper boundary " + rightBound);
											csvImportPane.errorMessage.setText("Error: user file contains the value " + floatArr[i] + " above the upper boundary " + rightBound);
											csvImportPane.error.getChildren().clear();
											csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
											csvImportPane.setBottom(csvImportPane.error);
										}
										else {
											dataset.add(floatArr[i]);
										}
									}
								} catch (NullPointerException nullExc) {
									errorLog.add("Error: NULL POINTER.");
									csvImportPane.errorMessage.setText("Error: NULL POINTER.");
									csvImportPane.error.getChildren().clear();
									csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
									csvImportPane.setBottom(csvImportPane.error);

								} catch (NumberFormatException numExc) {
									errorLog.add("Error: Data being added from file contains an invalid character.");
									csvImportPane.errorMessage.setText("Error: Data being added from file contains an invalid character.");
									csvImportPane.error.getChildren().clear();
									csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
									csvImportPane.setBottom(csvImportPane.error);
								} 
							}

							br.close();
						}
						catch (FileNotFoundException FNFExc) {
							errorLog.add("Error: user file " + csvImportPane.fileName.getText() + " not found.");
							//Error: user file not found
							csvImportPane.errorMessage.setText("Error: user file " + csvImportPane.fileName.getText() + " not found.");
							csvImportPane.error.getChildren().clear();
							csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
							csvImportPane.setBottom(csvImportPane.error);

						} 
						catch (IOException IOExc) {
							errorLog.add("Error: IOEXCEPTION.");
							//Error: IOException occurred.
							csvImportPane.errorMessage.setText("Error: IOEXCEPTION.");
							csvImportPane.error.getChildren().clear();
							csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
							csvImportPane.setBottom(csvImportPane.error);

						} finally {
							csvImportPane.fileName.clear();
						}
					});


					csvImportPane.backButton.setOnAction(e5 -> {
						csvImportPane.fileName.clear();
						primaryStage.setTitle("Import Menu");
						primaryStage.setScene(ImportScreen1);
					});
				}

				else {
					primaryStage.setScene(ImportScreen2);

					importPane2.backButton.setOnAction(f1 -> {
						primaryStage.setScene(ImportScreen1);
					});

					importPane2.newButton.setOnAction(f2 -> {
						primaryStage.setTitle("Import .csv File");
						primaryStage.setScene(CsvImportScreen);

						csvImportPane.importButton.setOnAction(a2 -> {
							dataset.clear();
							errorLog.clear();

							try {
								File in = new File(csvImportPane.fileName.getText());
								BufferedReader br = new BufferedReader(new FileReader(in)); 
								String readLine; 

								while ((readLine = br.readLine()) != null) {

									try {
										Float[] floatArr = Arrays.stream(readLine.split(",")).map(Float::valueOf).toArray(Float[]::new);

										for(int i = 0; i < floatArr.length; i++)
										{									
											if(floatArr[i] < leftBound) {
												errorLog.add("Error: user file contains the value " + floatArr[i] + " below the lower boundary " + leftBound);
												csvImportPane.errorMessage.setText("Error: user file contains the value " + floatArr[i] + " below the lower boundary " + leftBound);
												csvImportPane.error.getChildren().clear();
												csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
												csvImportPane.setBottom(csvImportPane.error);
											}
											else if(floatArr[i] > rightBound) {
												errorLog.add("Error: user file contains the value " + floatArr[i] + " above the upper boundary " + rightBound);
												csvImportPane.errorMessage.setText("Error: user file contains the value " + floatArr[i] + " above the upper boundary " + rightBound);
												csvImportPane.error.getChildren().clear();
												csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
												csvImportPane.setBottom(csvImportPane.error);
											}
											else {
												dataset.add(floatArr[i]);
											}
										}
									} catch (NullPointerException nullExc) {
										errorLog.add("Error: NULL POINTER.");
										csvImportPane.errorMessage.setText("Error: NULL POINTER.");
										csvImportPane.error.getChildren().clear();
										csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
										csvImportPane.setBottom(csvImportPane.error);

									} catch (NumberFormatException numExc) {
										errorLog.add("Error: Data being added from file contains an invalid character.");
										csvImportPane.errorMessage.setText("Error: Data being added from file contains an invalid character.");
										csvImportPane.error.getChildren().clear();
										csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
										csvImportPane.setBottom(csvImportPane.error);
									}
								}

								br.close();
							}
							catch (FileNotFoundException FNFExc) {
								errorLog.add("Error: user file " + csvImportPane.fileName.getText() + " not found.");
								//Error: user file not found
								csvImportPane.errorMessage.setText("Error: user file " + csvImportPane.fileName.getText() + " not found.");
								csvImportPane.error.getChildren().clear();
								csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
								csvImportPane.setBottom(csvImportPane.error);

							} 
							catch (IOException IOExc) {
								errorLog.add("Error: IOEXCEPTION.");
								//Error: IOException occurred.
								csvImportPane.errorMessage.setText("Error: IOEXCEPTION.");
								csvImportPane.error.getChildren().clear();
								csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
								csvImportPane.setBottom(csvImportPane.error);

							}
						});


						csvImportPane.backButton.setOnAction(e5 -> {
							csvImportPane.fileName.clear();
							primaryStage.setTitle("Import Menu");
							primaryStage.setScene(ImportScreen1);
						});
					});

					importPane2.appendButton.setOnAction(f3 -> {
						primaryStage.setTitle("Import .csv File");
						primaryStage.setScene(CsvImportScreen);

						csvImportPane.importButton.setOnAction(a2 -> {
							try {

								File in = new File(csvImportPane.fileName.getText());
								BufferedReader br = new BufferedReader(new FileReader(in)); 
								String readLine; 

								while ((readLine = br.readLine()) != null) {

									try {
										Float[] floatArr = Arrays.stream(readLine.split(",")).map(Float::valueOf).toArray(Float[]::new);

										for(int i = 0; i < floatArr.length; i++)
										{									
											if(floatArr[i] < leftBound) {
												errorLog.add("Error: user file contains the value " + floatArr[i] + " below the lower boundary " + leftBound);
												csvImportPane.errorMessage.setText("Error: user file contains the value " + floatArr[i] + " below the lower boundary " + leftBound);
												csvImportPane.error.getChildren().clear();
												csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
												csvImportPane.setBottom(csvImportPane.error);
											}
											else if(floatArr[i] > rightBound) {
												errorLog.add("Error: user file contains the value " + floatArr[i] + " above the upper boundary " + rightBound);
												csvImportPane.errorMessage.setText("Error: user file contains the value " + floatArr[i] + " above the upper boundary " + rightBound);
												csvImportPane.error.getChildren().clear();
												csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
												csvImportPane.setBottom(csvImportPane.error);
											}
											else {
												dataset.add(floatArr[i]);
											}
										}
									} catch (NullPointerException nullExc) {
										errorLog.add("Error: NULL POINTER.");
										csvImportPane.errorMessage.setText("Error: NULL POINTER.");
										csvImportPane.error.getChildren().clear();
										csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
										csvImportPane.setBottom(csvImportPane.error);

									} catch (NumberFormatException numExc) {
										errorLog.add("Error: Data being added from file contains an invalid character.");
										csvImportPane.errorMessage.setText("Error: Data being added from file contains an invalid character.");
										csvImportPane.error.getChildren().clear();
										csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
										csvImportPane.setBottom(csvImportPane.error);
									}
								}

								br.close();
							}
							catch (FileNotFoundException FNFExc) {
								errorLog.add("Error: user file " + csvImportPane.fileName.getText() + " not found.");
								//Error: user file not found
								csvImportPane.errorMessage.setText("Error: user file " + csvImportPane.fileName.getText() + " not found.");
								csvImportPane.error.getChildren().clear();
								csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
								csvImportPane.setBottom(csvImportPane.error);

							} 
							catch (IOException IOExc) {
								errorLog.add("Error: IOEXCEPTION.");
								//Error: IOException occurred.
								csvImportPane.errorMessage.setText("Error: IOEXCEPTION.");
								csvImportPane.error.getChildren().clear();
								csvImportPane.error.getChildren().add(csvImportPane.errorMessage);
								csvImportPane.setBottom(csvImportPane.error);

							}
						});


						csvImportPane.backButton.setOnAction(e5 -> {
							csvImportPane.fileName.clear();
							primaryStage.setTitle("Import Menu");
							primaryStage.setScene(ImportScreen1);
						});
					});
				}
			});
		});

		startPane.addButton.setOnAction(e6 -> {
			addDataPane.setBottom(addDataPane.bottom);
			primaryStage.setTitle("Add Data");
			primaryStage.setScene(AddDataScreen);

			addDataPane.menuButton.setOnAction(e7 -> {
				addDataPane.value.clear();
				primaryStage.setTitle("Main Menu");
				primaryStage.setScene(MainScreen);
			});

			addDataPane.addButton.setOnAction(a4 -> {
				float value = 0;
				if(dataset.isEmpty()) {
					errorLog.clear();
				}
				try {

					value = Float.parseFloat(addDataPane.value.getText());

					if(value < leftBound) {
						errorLog.add("Error: user entered the value " + value + " below the lower boundary " + leftBound);
						addDataPane.errorMessage.setText("Error: user entered the value " + value + " below the lower boundary " + leftBound);
						addDataPane.error.getChildren().clear();
						addDataPane.error.getChildren().add(addDataPane.errorMessage);
						addDataPane.setBottom(addDataPane.error);
					}
					else if(value > rightBound) {
						errorLog.add("Error: user entered the value " + value + " above the upper boundary " + rightBound);
						addDataPane.errorMessage.setText("Error: user entered the value " + value + " above the upper boundary " + rightBound);
						addDataPane.error.getChildren().clear();
						addDataPane.error.getChildren().add(addDataPane.errorMessage);
						addDataPane.setBottom(addDataPane.error);
					}
					else
						dataset.add(value);

				} catch (NumberFormatException numExc) {
					errorLog.add("Error: user entered an invalid character to insert.");
					addDataPane.errorMessage.setText("Error: user entered an invalid character to insert.");
					addDataPane.error.getChildren().clear();
					addDataPane.error.getChildren().add(addDataPane.errorMessage);
					addDataPane.setBottom(addDataPane.error);
				} 

				addDataPane.value.clear();
			});
		});

		startPane.deleteButton.setOnAction(e8 -> {
			deleteDataPane.setBottom(deleteDataPane.bottom);
			primaryStage.setTitle("Delete Data");
			primaryStage.setScene(DeleteDataScreen);

			deleteDataPane.menuButton.setOnAction(e9 -> {
				deleteDataPane.value.clear();
				primaryStage.setTitle("Main Menu");
				primaryStage.setScene(MainScreen);
			});

			deleteDataPane.deleteButton.setOnAction(a5 -> {
				try {					
					float value = 0;

					value = Float.parseFloat(deleteDataPane.value.getText());
					int index = 0;
					boolean found = false;
					while((index < dataset.size()) && (!found))
					{
						if (value == dataset.get(index))
						{
							dataset.remove(index);
							found = true;
						}
						index++;
					}

					if(!found) {
						errorLog.add("Error: value " + value + " not found within the datset, unable to remove an instance.");
						deleteDataPane.errorMessage.setText("Error: value " + value + " not found within the datset, unable to remove an instance.");
						deleteDataPane.error.getChildren().clear();
						deleteDataPane.error.getChildren().add(deleteDataPane.errorMessage);
						deleteDataPane.setBottom(deleteDataPane.error);
					}

				} catch (NumberFormatException numExc) {
					errorLog.add("Error: user entered an invalid character to delete.");
					deleteDataPane.errorMessage.setText("Error: user entered an invalid character to delete.");
					deleteDataPane.error.getChildren().clear();
					deleteDataPane.error.getChildren().add(deleteDataPane.errorMessage);
					deleteDataPane.setBottom(deleteDataPane.error);
				} 
				deleteDataPane.value.clear();
			});
		});

		startPane.setBoundariesButton.setOnAction(e10 -> {
			SetBoundariesPane setBoundariesPane = new SetBoundariesPane(leftBound, rightBound);
			SetBoundariesScreen = new Scene(setBoundariesPane, 600, 450);

			primaryStage.setTitle("Set Boundaries");
			primaryStage.setScene(SetBoundariesScreen);

			setBoundariesPane.menuButton.setOnAction(e11 -> {
				setBoundariesPane.lowerBoundary.clear();
				setBoundariesPane.upperBoundary.clear();
				primaryStage.setTitle("Main Menu");
				primaryStage.setScene(MainScreen);
			});

			setBoundariesPane.setButton.setOnAction(a6 -> {

				try {

					float newLower = 0;
					float newUpper = 0;

					newLower = Float.parseFloat(setBoundariesPane.lowerBoundary.getText());
					newUpper = Float.parseFloat(setBoundariesPane.upperBoundary.getText());

					if(newLower < newUpper)
					{
						boolean setValues = true;

						for(int i = 0; i < dataset.size(); i++) // Process the range and determine values outside of the new range
						{
							if((dataset.get(i) < newLower) || (dataset.get(i) > newUpper))
							{
								setValues = false;
								errorLog.add("Error: unable to change the range, value " + dataset.get(i) + " at index " + i + " in the dataset is outside the proposed bounds.");
								setBoundariesPane.errorMessage.setText("Error: unable to change the range, value " + dataset.get(i) + " at index " + i + " in the dataset is outside the proposed bounds.");
								setBoundariesPane.error.getChildren().clear();
								setBoundariesPane.error.getChildren().add(setBoundariesPane.errorMessage);
								setBoundariesPane.setBottom(setBoundariesPane.error);
							}
						}

						if(setValues)
						{
							leftBound = newLower;
							rightBound = newUpper;
							setBoundariesPane.lowerBoundary.clear();
							setBoundariesPane.upperBoundary.clear();
							primaryStage.setTitle("Main Menu");
							primaryStage.setScene(MainScreen);
						}
					}
					else
					{
						errorLog.add("Error: unable to set the range. Lower bound " + newLower + " is not less than upper bound " + newUpper + ".");
						setBoundariesPane.errorMessage.setText("Error: unable to set the range. Lower bound " + newLower + " is not less than upper bound " + newUpper + ".");
						setBoundariesPane.error.getChildren().clear();
						setBoundariesPane.error.getChildren().add(setBoundariesPane.errorMessage);
						setBoundariesPane.setBottom(setBoundariesPane.error);
					}

				} catch (NumberFormatException numExc) {
					errorLog.add("Error: user entered an invalid character to set as a bound.");
					setBoundariesPane.errorMessage.setText("Error: user entered an invalid character to set as a bound.");
					setBoundariesPane.error.getChildren().clear();
					setBoundariesPane.error.getChildren().add(setBoundariesPane.errorMessage);
					setBoundariesPane.setBottom(setBoundariesPane.error);
				}

				setBoundariesPane.lowerBoundary.clear();
				setBoundariesPane.upperBoundary.clear();
			});

		});

		startPane.analyzeButton.setOnAction(e12 -> {
			AnalysisPane analysisPane = new AnalysisPane(dataset, leftBound, rightBound);
			AnalysisScreen = new Scene(analysisPane, 600, 450);
			primaryStage.setTitle("Analysis");
			primaryStage.setScene(AnalysisScreen);

			analysisPane.menuButton.setOnAction(e13 -> {
				primaryStage.setTitle("Main Menu");
				primaryStage.setScene(MainScreen);
			});
		});

		startPane.distributionButton.setOnAction(e14 -> {
			DistributionPane distributionPane = new DistributionPane(dataset, leftBound, rightBound);
			DistributionScreen = new Scene(distributionPane, 600, 450);
			primaryStage.setTitle("Distribution");
			primaryStage.setScene(DistributionScreen);

			distributionPane.menuButton.setOnAction(e15 -> {
				primaryStage.setTitle("Main Menu");
				primaryStage.setScene(MainScreen);
			});
		});

		startPane.graphButton.setOnAction(e16 -> {
			GraphPane graphPane = new GraphPane(dataset, leftBound, rightBound);
			GraphScreen = new Scene(graphPane, 600, 450);
			primaryStage.setTitle("Graph");
			primaryStage.setScene(GraphScreen);

			graphPane.menuButton.setOnAction(e17 -> {
				primaryStage.setTitle("Main Menu");
				primaryStage.setScene(MainScreen);
			});			
		});

		startPane.errorButton.setOnAction(e17 -> {
			ErrorPane errorPane = new ErrorPane(errorLog);
			ErrorScreen = new Scene(errorPane);
			primaryStage.setTitle("Error Log");
			primaryStage.setScene(ErrorScreen);

			errorPane.menuButton.setOnAction(e18 -> {
				primaryStage.setTitle("Main Menu");
				primaryStage.setScene(MainScreen);
			});
		});
		
		startPane.displayButton.setOnAction(e18 -> {
			DisplayPane displayPane = new DisplayPane(dataset);
			DisplayScreen = new Scene(displayPane, 600, 450);
			primaryStage.setTitle("Data Display");
			primaryStage.setScene(DisplayScreen);

			displayPane.menuButton.setOnAction(e19 -> {
				primaryStage.setTitle("Main Menu");
				primaryStage.setScene(MainScreen);
			});
		});

		startPane.reportButton.setOnAction(e17 -> {

			File reportFile = new File("report.txt");


			try {

				BufferedWriter out = new BufferedWriter(new FileWriter(reportFile, false));

				//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Print everything to out ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

				// Print Analysis / calculations

				AnalysisPane analysisPane = new AnalysisPane(dataset, leftBound, rightBound);

				out.write("Analysis:\n");

				out.write("Number of entries: ");
				out.write(dataset.size() + "\n");

				out.write(analysisPane.high.getText() + "\n");

				out.write(analysisPane.mean.getText() + "\n");

				out.write(analysisPane.median.getText() + "\n");

				out.write(analysisPane.mode.getText() + "\n");

				out.write("\n");

				// Print Graph

				GraphPane graphPane = new GraphPane(dataset, leftBound, rightBound);
				out.write("Graph:\n");

				out.write("90: ");
				out.write(printGraph(graphPane.ninetyData) + "\n");

				out.write("80: ");
				out.write(printGraph(graphPane.eightyData) + "\n");

				out.write("70: ");
				out.write(printGraph(graphPane.seventyData) + "\n");

				out.write("60: ");
				out.write(printGraph(graphPane.sixtyData) + "\n");

				out.write("50: ");
				out.write(printGraph(graphPane.fiftyData) + "\n");

				out.write("40: ");
				out.write(printGraph(graphPane.fortyData) + "\n");

				out.write("30: ");
				out.write(printGraph(graphPane.thirtyData) + "\n");

				out.write("20: ");
				out.write(printGraph(graphPane.twentyData) + "\n");

				out.write("10: ");
				out.write(printGraph(graphPane.tenData) + "\n");

				out.write("0:  ");
				out.write(printGraph(graphPane.zeroData) + "\n");

				out.write("\n");


				// Print Distributions

				DistributionPane distributionPane = new DistributionPane(dataset, leftBound, rightBound);
				out.write("Distributions:\n");
				out.write(distributionPane.ninety.getText() + "\t");
				out.write(distributionPane.ninetyAvgLabel.getText() + "\n");

				out.write(distributionPane.eighty.getText() + "\t");
				out.write(distributionPane.eightyAvgLabel.getText() + "\n");

				out.write(distributionPane.seventy.getText() + "\t");
				out.write(distributionPane.seventyAvgLabel.getText() + "\n");

				out.write(distributionPane.sixty.getText() + "\t");
				out.write(distributionPane.sixtyAvgLabel.getText() + "\n");

				out.write(distributionPane.fifty.getText() + "\t");
				out.write(distributionPane.fiftyAvgLabel.getText() + "\n");

				out.write(distributionPane.forty.getText() + "\t");
				out.write(distributionPane.fortyAvgLabel.getText() + "\n");

				out.write(distributionPane.thirty.getText() + "\t");
				out.write(distributionPane.thirtyAvgLabel.getText() + "\n");

				out.write(distributionPane.twenty.getText() + "\t");
				out.write(distributionPane.twentyAvgLabel.getText() + "\n");

				out.write(distributionPane.ten.getText() + "\t");
				out.write(distributionPane.tenAvgLabel.getText() + "\n");

				out.write(distributionPane.zero.getText() + " \t");
				out.write(distributionPane.zeroAvgLabel.getText() + "\n");

				out.write("\n");


				// Print Error Log

				out.write("Error Log:\n");

				for(int i = 0; i < errorLog.size(); i++)
				{
					out.write(errorLog.get(i) + "\n");
				}					


				out.close();
			} catch (FileNotFoundException e1) {
				errorLog.add("Error: unable to add data to the report.txt file.");
			} catch (IOException e2) {
				errorLog.add("Error: IOException");
			} 
		});


		startPane.exitButton.setOnAction(e99 -> Platform.exit());
	}

	public static void main(String[] args)
	{
		Application.launch(args);
	}

	public String printGraph(int amount)
	{
		String toReturn = "";

		for(int i = 0; i < amount; i++)
		{
			toReturn += "x";
		}

		return toReturn;
	}

}
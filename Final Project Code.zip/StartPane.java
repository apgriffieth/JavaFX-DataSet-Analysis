import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.layout.HBox;

public class StartPane extends BorderPane
{
	public Button importButton, addButton, deleteButton, setBoundariesButton,
	analyzeButton, displayButton, graphButton, distributionButton, errorButton, 
	reportButton, exitButton;
	private Pane mainScreen;
	public HBox bottom;
	
	public StartPane() {
		
		exitButton = new Button("Exit");
		exitButton.setMinWidth(80);
		
		importButton = new Button("Import a Dataset");
		importButton.setMinWidth(153);
		addButton = new Button("Add to Dataset");
		addButton.setMinWidth(153);
		deleteButton = new Button("Delete From Dataset");
		deleteButton.setMinWidth(153);
		setBoundariesButton = new Button("Set Boundaries of Dataset");
		analyzeButton = new Button("Analyze Dataset");
		analyzeButton.setMinWidth(153);
		displayButton = new Button("Display Dataset");
		displayButton.setMinWidth(153);
		graphButton = new Button("Display Graph");
		graphButton.setMinWidth(153);
		distributionButton = new Button("Show Distribution");
		distributionButton.setMinWidth(153);
		errorButton = new Button("Show Error Log");
		errorButton.setMinWidth(153);
		reportButton = new Button("Create Report");
		reportButton.setMinWidth(153);
		
		VBox leftHalf = new VBox();
		leftHalf.setPrefSize(300, 550);
		leftHalf.setPadding(new Insets(10, 12, 10, 12));
		leftHalf.setSpacing(40);
		leftHalf.setAlignment(Pos.TOP_LEFT);
		leftHalf.setStyle("-fx-border-color: black");
		leftHalf.getChildren().addAll(importButton, addButton, deleteButton, 
				setBoundariesButton, analyzeButton);
		
		VBox rightHalf = new VBox();
		rightHalf.setPrefSize(300,  550);
		rightHalf.setPadding(new Insets(10, 12, 10, 12));
		rightHalf.setSpacing(40);
		rightHalf.setAlignment(Pos.TOP_LEFT);
		rightHalf.setStyle("-fx-border-color: black");
		rightHalf.getChildren().addAll(displayButton, graphButton, distributionButton,
				errorButton, reportButton);

		mainScreen = new Pane();
		mainScreen.setPrefSize(300, 550);
		mainScreen.setStyle("-fx-background-color: beige;");		
		//mainScreen.getChildren().add(optionCombo);
		
		bottom = new HBox();
		bottom.setPrefSize(400, 50);
		bottom.setPadding(new Insets(10, 12, 10, 12));
		bottom.setSpacing(40);
		bottom.setAlignment(Pos.BOTTOM_CENTER);
		bottom.setStyle("-fx-border-color: black");
		bottom.getChildren().add(exitButton);
		
		this.setCenter(mainScreen);
		this.setLeft(leftHalf);
		this.setRight(rightHalf);
		this.setBottom(bottom);
	}
}//end class DrawPane
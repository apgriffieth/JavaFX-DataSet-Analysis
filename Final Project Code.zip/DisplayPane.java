import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;	
import javafx.geometry.HPos;
import javafx.scene.paint.Color;
import java.util.*;

public class DisplayPane extends BorderPane {
	public Button menuButton;
	public VBox column1, column2, column3, column4;
	
	public DisplayPane(ArrayList<Float> dataSet) {
		Collections.sort(dataSet);
		Collections.reverse(dataSet);
		menuButton = new Button("Return to Main Menu");
		
		column1 = new VBox();
		column1.setPrefSize(300, 550);
		column1.setPadding(new Insets(10, 12, 10, 12));
		column1.setAlignment(Pos.TOP_LEFT);
		column1.setStyle("-fx-border-color: black");
		
		column2 = new VBox();
		column2.setPrefSize(300, 550);
		column2.setPadding(new Insets(10, 12, 10, 12));
		column2.setAlignment(Pos.TOP_LEFT);
		column2.setStyle("-fx-border-color: black");
		
		column3 = new VBox();
		column3.setPrefSize(300, 550);
		column3.setPadding(new Insets(10, 12, 10, 12));
		column3.setAlignment(Pos.TOP_LEFT);
		column3.setStyle("-fx-border-color: black");
		
		column4 = new VBox();
		column4.setPrefSize(300, 550);
		column4.setPadding(new Insets(10, 12, 10, 12));
		column4.setAlignment(Pos.TOP_LEFT);
		column4.setStyle("-fx-border-color: black");
		
		if(!dataSet.isEmpty()) {
			int amount = dataSet.size() / 4;
			int extra = dataSet.size() % 4;
			
			if(extra == 0) {
				for(int i = 0; i < amount; i++) {
					Label value;
					column1.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount; i < amount * 2; i++) {
					Label value;
					column2.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount * 2; i < amount * 3; i++) {
					Label value;
					column3.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount * 3; i < dataSet.size(); i++) {
					Label value;
					column4.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
			}
			
			else if(extra == 1) {
				for(int i = 0; i < amount + 1; i++) {
					Label value;
					column1.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount + 1; i < amount * 2 + 1; i++) {
					Label value;
					column2.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount * 2 + 1; i < amount * 3 + 1; i++) {
					Label value;
					column3.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount * 3 + 1; i < dataSet.size(); i++) {
					Label value;
					column4.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
			}
			
			else if(extra == 2) {
				for(int i = 0; i < amount + 1; i++) {
					Label value;
					column1.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount + 1; i < amount * 2 + 2; i++) {
					Label value;
					column2.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount * 2 + 2; i < amount * 3 + 2; i++) {
					Label value;
					column3.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount * 3 + 2; i < dataSet.size(); i++) {
					Label value;
					column4.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
			}
			
			else if(extra == 3) {
				for(int i = 0; i < amount + 1; i++) {
					Label value;
					column1.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount + 1; i < amount * 2 + 2; i++) {
					Label value;
					column2.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount * 2 + 2; i < amount * 3 + 3; i++) {
					Label value;
					column3.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
				
				for(int i = amount * 3 + 3; i < dataSet.size(); i++) {
					Label value;
					column4.getChildren().add(value = new Label("" + dataSet.get(i)));
				}
			}
		}
		
		GridPane mainScreen = new GridPane();
		mainScreen.setHgap(5.5);
		mainScreen.setVgap(5.5);
		mainScreen.setPadding(new Insets(50, 10, 10, 30));
		mainScreen.setPrefSize(300,  550);
		mainScreen.setStyle("-fx-background-color: beige;");
		
		mainScreen.add(column1, 0, 0);
		mainScreen.add(column2, 1, 0);
		mainScreen.add(column3, 2, 0);
		mainScreen.add(column4, 3, 0);
		
		this.setCenter(mainScreen);
		this.setTop(menuButton);
	}
}
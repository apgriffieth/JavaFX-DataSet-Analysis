import javafx.scene.layout.Pane;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.layout.GridPane;	
import javafx.geometry.HPos;
import javafx.scene.paint.Color;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import java.util.*;

public class GraphPane extends BorderPane {
	public Button menuButton;
	public String ninety, eighty, seventy, sixty, fifty, forty, thirty, 
	twenty, ten, zero;
	public int ninetyData, eightyData, seventyData, sixtyData, fiftyData, fortyData,
	thirtyData, twentyData, tenData, zeroData = 0;
	Pane mainScreen = new Pane();

	public GraphPane(ArrayList<Float> dataSet, float leftBound, float rightBound) {
		menuButton = new Button("Return to Main Menu");
		
		float distance = (rightBound - leftBound) / 10;
		ninety = "90 - 100%";
		eighty = "80 - 90%";
		seventy = "70 - 80%";
		sixty = "60 - 70%";
		fifty = "50 - 60%";
		forty = "40 - 50%";
		thirty = "30 - 40%";
		twenty = "20 - 30%";
		ten = "10 - 20%";
		zero = "0 - 10%";

		for(int i = 0; i < dataSet.size(); i++) {


			if (dataSet.get(i) / distance < 1) {
				zeroData++;
			}

			else if (dataSet.get(i) / distance >= 1 && dataSet.get(i) / distance < 2) {
				tenData++;
			}

			else if (dataSet.get(i) / distance >= 2 && dataSet.get(i) / distance < 3) {
				twentyData++;
			}

			else if (dataSet.get(i) / distance >= 3 && dataSet.get(i) / distance < 4) {
				thirtyData++;
			}

			else if (dataSet.get(i) / distance >= 4 && dataSet.get(i) / distance < 5) {
				fortyData++;				
			}

			else if (dataSet.get(i) / distance >= 5 && dataSet.get(i) / distance < 6) {
				fiftyData++;
			}

			else if (dataSet.get(i) / distance >= 6 && dataSet.get(i) / distance < 7) {
				sixtyData++;
			}

			else if (dataSet.get(i) / distance >= 7 && dataSet.get(i) / distance < 8) {
				seventyData++;
			}

			else if (dataSet.get(i) / distance >= 8 && dataSet.get(i) / distance < 9) {
				eightyData++;
			}

			else {
				ninetyData++;
			}
		}
		
		List<Integer> list = Arrays.asList(zeroData, tenData, twentyData, thirtyData,
				fortyData, fiftyData, sixtyData, seventyData, eightyData, ninetyData);
		
		CategoryAxis yAxis = new CategoryAxis();
		NumberAxis xAxis = new NumberAxis(0, Collections.max(list) + 1, 1);

		BarChart<Number,String> barChart = new BarChart<Number,String>(xAxis, yAxis);
		barChart.setLegendVisible(false);
		barChart.setTitle("Distribution of Data");
		xAxis.setLabel("Count");
		xAxis.setTickLabelRotation(90);
		yAxis.setLabel("Percentage");

		XYChart.Series series1 = new XYChart.Series();
		series1.getData().add(new XYChart.Data(zeroData, zero));
		series1.getData().add(new XYChart.Data(tenData, ten));
		series1.getData().add(new XYChart.Data(twentyData, twenty));
		series1.getData().add(new XYChart.Data(thirtyData, thirty));
		series1.getData().add(new XYChart.Data(fortyData, forty));
		series1.getData().add(new XYChart.Data(fiftyData, fifty));
		series1.getData().add(new XYChart.Data(sixtyData, sixty));
		series1.getData().add(new XYChart.Data(seventyData, seventy));
		series1.getData().add(new XYChart.Data(eightyData, eighty));
		series1.getData().add(new XYChart.Data(ninetyData, ninety));

		barChart.getData().add(series1);

		mainScreen = new Pane();
		mainScreen.setPrefSize(300, 550);
		mainScreen.setStyle("-fx-background-color: beige;");		
		mainScreen.getChildren().add(barChart);

		this.setCenter(mainScreen);
		this.setTop(menuButton);
	}
}
